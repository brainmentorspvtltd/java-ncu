package com.brainmentors.shopping.orders;

public class CashPayment extends Payment {

}
