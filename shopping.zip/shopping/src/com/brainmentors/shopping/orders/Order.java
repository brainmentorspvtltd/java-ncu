package com.brainmentors.shopping.orders;

public class Order {
	Payment payment =new Payment();
}
