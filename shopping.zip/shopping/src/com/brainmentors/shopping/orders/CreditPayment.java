package com.brainmentors.shopping.orders;

public class CreditPayment extends Payment {

}
